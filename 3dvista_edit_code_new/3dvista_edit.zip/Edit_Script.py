import json
import os
import math
import time

class Add_Json_Data():
    def __init__(self, path, dbpath):
        self.path = path
        self.dbpath = dbpath
        self.json_open = open(self.path,'r', encoding='cp932', errors='ignore')
        self.db_open = open(self.dbpath,'r')
        self.json_load = json.load(self.json_open)
        self.db_load = json.load(self.db_open)
        self.number_panorama = 0
        self.connect_hotspot = []       ###[[[画像名,x座標,y座標]]]の三次元
        self.number_hotspot = []
        self.overlays = []
        self.areas = []
        self.behaviours = []
        self._get_number_panorama()
        self._get_connect_hotspot()
        self._get_number_hotspot()

        self.remember_panorama_info()

        self._get_overlays()
        self._get_areas()
        self._get_behaviours()
        

    def _get_number_panorama(self):
        json_definition = self.json_load["player"]["definitions"]
        count = 0
        for i in range(len(json_definition)):
            for v in json_definition[i].keys():
                if(v=='hfovMin'):
                    count+=1
        self.number_panorama = count
    
    def _get_connect_hotspot(self):
        
        for i in self.db_load.keys():
            pre_connect_hotspot = []
            for j in range(len(self.db_load[i])):
                angle = self.db_load[i][j][2] ##角度を取ってきたい
                # angle = math.radians(angle) ##ラジアンに変換したい
                # print(angle)
                # print(angle)
                pre_connect_hotspot.append([self.db_load[i][j][0],700+700*angle/math.pi, angle*180/math.pi])  ##connect_hotspotに名前,x, yでappendしたい
            self.connect_hotspot.append(pre_connect_hotspot)
        print(self.connect_hotspot)

        
    
    def _get_number_hotspot(self):
        for i in range(self.number_panorama):
            self.number_hotspot.append(len(self.connect_hotspot[i]))
    
    def _get_overlays(self):
        for i in range(self.number_panorama):
            for j in range(self.number_hotspot[i]):
                if j == 0:
                    self.overlays.append({"overlays":[f"this.overlay_C{i}_{j}"]})
                else:
                    self.overlays[i]["overlays"].append(f"this.overlay_C{i}_{j}")
    
    def _get_areas(self):
        for i in range(self.number_panorama):
            self.areas.append([])

        for i in range(self.number_panorama):
            for j in range(self.number_hotspot[i]):
                yaw = 10*j
                self.areas[i].append({"areas":[f"this.HotspotPanoramaOverlayArea_C{i}_{j}"],
                        "class":"HotspotPanoramaOverlayEditable",
                        "excludeClickGoMode":False,
                        "items":[{"visibleOnStop":False,
                        "hfov":7.616601683506721,
                        "playEvent":"start",
                        "label":"Arrow 01",
                        "verticalAlign":"middle",
                        "width":33.33333333333333,
                        "loop":True,
                        "path":"hotspots/Hotspot_34559710_3D00_0B16_41B3_160403C9DC33.png",
                        "showFrameAtStart":0,
                        "stopEvent":"none",
                        "class":"HotspotPanoramaOverlayAnimatedBitmapImage",
                        "yaw":self.connect_hotspot[i][j][2],
                        "libraryData":{"type":"goToPanoramaWall",
                        "name":"arrow01",
                        "element":"IHotspotOverlayBitmapImage",
                        "family":"animated"},
                        "pitch":-20,
                        "pauseEvent":"none",
                        "x":self.connect_hotspot[i][j][1],
                        "fps":16,
                        "y":400,
                        "horizontalAlign":"center",
                        "scaleMode":"fit_inside",
                        "transparencyActive":True,
                        "factorHeight":3.751570132588974,
                        "distance":100,
                        "height":30,
                        "factorWidth":3.751570132588974}],
                        "rollOverDisplay":False,
                        "useHandCursor":True,
                        "maps":[],
                        "id":f"overlay_C{i}_{j}",
                        "hasChanges":True})

    def _get_behaviours(self):
        for i in range(self.number_panorama):
            self.behaviours.append([])

        for i in range(self.number_panorama):
            for j in range(self.number_hotspot[i]):
                connect_hotspot_id = self.remember_name_id[f"{self.connect_hotspot[i][j][0]}"] ##名前とidの辞書からパノラマのid取得
                # print(connect_hotspot_id)
                self.behaviours[i].append({"class":"HotspotPanoramaOverlayArea",
                            "id":f"HotspotPanoramaOverlayArea_C{i}_{j}",
                            "behaviours":[{"media":f"this.{connect_hotspot_id}",    ###パノラマのid反映
                            "class":"PanoramaBehaviour",
                            "event":"click",
                            "startPointView":{"type":"smartPoint",
                            "class":"StartPointView"},
                            "sentences":[],
                            "inComponent":"this.MainViewer",
                            "action":"openPanorama",
                            "where":"inViewer"}]})
    def remember_context_panorama(self):
        self.remember_context = [] ##今までのremember
        json_definition = self.json_load["player"]["definitions"]
        for i in range(len(json_definition)):
            for v in json_definition[i].keys():
                if(v=='hfovMin'):
                    self.remember_context.append(json_definition[i])

    def remember_position_panorama(self):
        self.remember_number = []
        json_definition = self.json_load["player"]["definitions"]
        for i in range(len(json_definition)):
            for v in json_definition[i].keys():
                if(v=='hfovMin'):
                    self.remember_number.append(i)
    
    def remember_name_and_id_panorama(self):
        self.remember_path = []
        self.remember_id = []
        self.remember_filename = []
        self.remember_name_id = {}
        for i in range(len(self.remember_context)):
            self.remember_path.append(self.remember_context[i]["paths"])
            self.remember_id.append(self.remember_context[i]['id'])

        for i in range(len(self.remember_path)):
            self.remember_filename.append(os.path.basename(self.remember_path[i][0]).split(".")[0])
        
        count = 0
        for v in self.remember_filename:
            self.remember_name_id[f"{v}"] = self.remember_id[count]
            count += 1
        # print(self.remember_name_id)
    
    def remember_panorama_info(self):
        self.remember_context_panorama()
        self.remember_position_panorama()
        self.remember_name_and_id_panorama()


    def insert_overlays(self):
        self.remember_context_panorama()
        self.remember_position_panorama()
        # overlayをそれぞれに追加
        for i in range(len(self.remember_context)):
            self.remember_context[i].update(self.overlays[i])

        # json_loadに　overlay追加したのを入れる
        count = 0
        for i in self.remember_number:
            self.json_load['player']['definitions'][i] = self.remember_context[count]
            count += 1
    
    def insert_areas(self):
        for i in range(self.number_panorama):
            for j in range(self.number_hotspot[i]):
                self.json_load["player"]["definitions"].append(self.areas[i][j])
    
    def insert_behaviours(self):
        for i in range(self.number_panorama):
            for j in range(self.number_hotspot[i]):
                self.json_load["player"]["definitions"].append(self.behaviours[i][j])

    def save_to_json(self,save_path):
        with open(save_path, mode='wt', encoding='utf-8') as file:
            json.dump(self.json_load, file, ensure_ascii=False, indent=2)

    def file_close (self):
        self.json_open.close()
        self.db_open.close()


def main():
    AJD = Add_Json_Data(r"C:\Users\owner\Documents\3dvista_automation\test_code\script.js", "data_base.js")
    AJD.insert_overlays()
    AJD.insert_areas()
    AJD.insert_behaviours()
    AJD.save_to_json("script.json")
    AJD.file_close()


if __name__ == "__main__":
    main()
